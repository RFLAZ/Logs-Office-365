# Office 365 · Actividad por usuario

Herramienta independiente del conversor CSV → XLSX. Acepta CSV originales o los XLSX generados por el conversor y produce un único informe Excel, con todos los eventos incluidos ordenados cronológicamente. El análisis de archivos funciona localmente y sin conexión en Windows, macOS o Linux. La consulta opcional de reputación con AbuseIPDB requiere Internet, Python 3 y una clave API. El script incluido abre la interfaz y realiza las consultas.

## Descargar y abrir

1. [Descarga office365-actividad.zip](https://github.com/RFLAZ/Logs-Office-365/raw/refs/heads/main/office365-actividad.zip).
2. Descomprime el ZIP y ejecuta `python3 iniciar.py` para que se abra la interfaz, como se explica debajo. Si solo necesitas análisis sin reputación, puedes abrir `index.html` directamente.
3. Selecciona uno o varios CSV o XLSX. Para reputación, activa AbuseIPDB, pega la clave y pulsa **Generar informe y consultar IP**. Sin reputación, pulsa **Generar tabla de actividad**.
4. Descarga `actividad_office365.xlsx`.

En el repositorio puedes abrir `dist/actividad.html`. Para el análisis sin reputación no necesitas Python, Node.js, acceso a Microsoft 365 ni subir tus archivos a un servidor.

## Reputación de IP con AbuseIPDB

El navegador no puede ejecutar un script del ordenador ni controlar las restricciones CORS del proveedor. Esta versión incluye **`iniciar.py`**, un único script Python que contiene toda la interfaz, abre el navegador y realiza las consultas para el HTML. No hay archivos `.command` y no hace falta desactivar las protecciones del Mac.

1. Descomprime el ZIP.
2. En Mac abre Terminal, escribe `python3 ` (con un espacio al final), arrastra `iniciar.py` desde Finder a Terminal y pulsa Intro. También puedes ejecutar `python3 iniciar.py` desde su carpeta; en Windows, `py -3 iniciar.py`. Requiere Python 3, sin paquetes adicionales. El script incluye certificados raíz de Mozilla para las instalaciones de Python que no tengan un almacén de confianza configurado.
3. Se abre automáticamente la interfaz. Usa esa pestaña y mantén abierta la ventana de Terminal.
4. Carga el CSV o XLSX, activa **Consultar reputación de IP con AbuseIPDB**, pega tu clave y pulsa **Generar informe y consultar IP**.
5. Descarga el Excel con **Actividad**, **Resumen por usuario** y **Reputación IP**. Termina con Ctrl+C en Terminal cuando ya no necesites la aplicación.

`iniciar.py` es autónomo: puedes moverlo o copiarlo a otra carpeta y seguirá funcionando sin los otros archivos del ZIP. El HTML incluido se puede abrir por separado para analizar sin reputación; no puede arrancar el script por sí solo. Si el navegador no se abre automáticamente, la dirección local aparece en Terminal. Para desarrollo puedes ejecutar `python3 local/iniciar.py` después de compilar. El script empaquetado se genera con `npm run package`.

Pegar la clave no consume cuota. La autenticación se comprueba al consultar la primera IP pública. El HTML envía las IP y la clave al script en `127.0.0.1`, y este llama a `https://api.abuseipdb.com/api/v2/check`, con verificación TLS y sin seguir redirecciones. Así la conexión con AbuseIPDB no depende de CORS. El script conserva los certificados por defecto de Python y añade el paquete oficial de raíces Mozilla/certifi 2026.10.19, verificado por SHA-256 y embebido en el propio archivo; no descarga ni instala certificados al ejecutarse. La comprobación de la cadena del certificado y del nombre del servidor permanece activa. La clave va en la cabecera `Key` al proveedor, no en la URL. No se envían al proveedor usuarios, acciones, archivos ni logs completos, ni se usan proxies públicos. La clave no se guarda en el navegador, archivos, registros del script o Excel y se borra del formulario al terminar.

Se normalizan IPv4 con puerto, IPv6 entre corchetes e IPv4 mapeada para evitar duplicados. Se omiten IP privadas, reservadas e inválidas, y se calcula localmente su número de eventos y usuarios asociados. El límite es por informe (100 peticiones por defecto), no la cuota diaria de tu cuenta. Se detienen las consultas al alcanzar el límite, recibir cuota agotada o producirse un error; el Excel conserva el informe y marca cada IP no consultada o fallida. No hay reintentos automáticos. Puedes **Cancelar consultas y generar informe** para conservar lo obtenido; una petición enviada puede haber consumido cuota.

La hoja incluye puntuación de confianza de abuso (0–100), informes e informantes, última notificación, país, ISP, dominio, tipo de uso, lista blanca y fecha de consulta. Puntuación vacía significa que no hay resultado, no una puntuación cero. Es reputación actual basada en el período seleccionado; no reconstruye la reputación en la fecha del evento. Una puntuación cero no acredita que una IP sea segura.

La integración se valida con el script real y respuestas de AbuseIPDB simuladas; no se ha usado una clave real en este entorno. Los errores de autenticación, cuota, conexión y certificados se indican sin revelar claves ni desactivar verificaciones.

## Excluir UserLoginFailed

La opción **Excluir UserLoginFailed del informe y de las consultas de IP** está activada por defecto. Se aplica después de leer todos los archivos y antes de crear la actividad, los resúmenes y la lista de IP de AbuseIPDB. Coincide únicamente con la acción `UserLoginFailed` (sin distinguir mayúsculas o espacios al principio/final), no con cualquier evento cuyo resultado indique un fallo.

Una IP que solo aparece en eventos excluidos no se consulta. Si también figura en otra acción incluida, se mantiene y se consulta una sola vez; sus contadores reflejan únicamente los eventos incluidos. Se muestra el número de eventos leídos, excluidos e incluidos y se guarda en **Resumen del análisis**. Si todos los eventos se excluyen, el informe lo indica y no consume consultas de IP.

Puedes desmarcar la opción para incluir esos eventos. Los archivos de entrada no se modifican; para recuperar eventos que ya no estén en un informe filtrado, carga el CSV original. Al analizar un XLSX previo se leen sus hojas de registros o actividad, sin tratar la reputación y los resúmenes como eventos nuevos.

## Hojas del informe

**Actividad:** una fila por evento con fecha UTC, usuario, acción, IP, ubicación, país, origen del país, resultado, aplicación o servicio, recurso, ID del registro, archivo, hoja y fila o registro de origen. Orden ascendente de fecha, filtros y primera fila fija. Filtra la columna Usuario para ver todas las acciones de una cuenta.

**Resumen del análisis:** filtro aplicado, eventos de entrada, UserLoginFailed excluidos y eventos incluidos.

**Resumen por usuario:** número de eventos, acciones distintas, IP distintas, primera y última fecha. Las cuentas sin usuario identificado se agrupan en una fila separada como «No consta en el registro».

El informe no elimina eventos repetidos. Si cargas varios archivos se combinan todos y se ordenan por fecha globalmente. No selecciones simultáneamente un CSV y su XLSX equivalente, salvo que quieras contar ambos.

## Filtrar conexiones satisfactorias de SignIns en Reputación IP

La hoja **Reputación IP** incluye, después de la dirección IP:

- **Estado de conexión:** el valor original del campo `Estado` del CSV de SignIns (por ejemplo, `Êxito`, `Éxito`, `Success` o `Falha`). Al cargar un XLSX de actividad se recupera de su columna `Resultado`.
- **Conexión satisfactoria:** `Sí`, `No` o `No determinado`. Para ver solo accesos satisfactorios, usa el filtro de esta columna y selecciona **Sí**.

Se crea una fila por combinación de **IP y estado de conexión**. Si una IP aparece tanto en conexiones satisfactorias como fallidas, se mantienen filas separadas; la misma respuesta de AbuseIPDB se reutiliza en todas ellas. Se hace **una única consulta por IP**, y los límites se aplican a IP distintas, no al número de filas. Las columnas `Eventos` y `Usuarios distintos` cuentan solo los registros de esa IP con ese estado.

**Estado de consulta** sigue indicando el resultado de la consulta a AbuseIPDB; es independiente del éxito del inicio de sesión. Un acceso satisfactorio puede tener un error o una consulta omitida en la reputación, y se conserva el dato de conexión en esos casos. No se eliminan automáticamente los SignIns fallidos.

Para UAL y AuthDetails, cuyo resultado no acredita por sí solo una conexión de SignIns completa, estas columnas indican `No aplica`. Si SignIns no incluye el estado, se muestra `No consta en el registro` y `No determinado`. Los estados desconocidos se conservan sin clasificarlos como éxito.

## Ubicación y país junto a la IP

La hoja **Actividad** coloca **Ubicación**, **País** y **Origen del país** inmediatamente después de **IP**.

- Se usa primero la ubicación presente en el propio evento: `Localização` de los CSV portugueses de SignIns, `Location`, `Ubicación`, objetos JSON de ubicación o sus columnas expandidas. Se conservan los valores de ciudad/región y se reconocen los códigos de país. Los códigos de dos letras se muestran con su nombre en español cuando el navegador lo permite.
- En el formato habitual de SignIns `ciudad, estado/región, código de país` se conserva el texto de ubicación y se separa el país. Un texto ambiguo con solo ciudad y estado no se interpreta como un país.
- Si falta el país y se activa AbuseIPDB, se completa únicamente con el país de las consultas ya realizadas y correctas para esa IP. No se hacen consultas adicionales ni se consume más cuota por esta columna. No se sobrescribe el país que figura en el registro.
- **Origen del país** indica `Registro` o `AbuseIPDB`. Los datos de AbuseIPDB son actuales; el dato del registro corresponde al evento. Esta versión no obtiene ciudades de AbuseIPDB ni deduce ubicaciones físicas exactas.
- Cuando no hay dato se muestra **No consta en el registro**. Las consultas omitidas o fallidas no aportan país. Las filas con varias IP diferentes no se enriquecen con un único país de AbuseIPDB para evitar atribuciones ambiguas.
- Al volver a cargar un XLSX de actividad se conservan las columnas de ubicación y su origen.

## Origen de los datos

- Para UAL se consultan los campos de `AuditData` y sus columnas expandidas: `CreationTime`, `UserId`, `Operation`, `ClientIP`, `ResultStatus`, `Workload` y `ObjectId`, con alternativas conocidas en las columnas originales.
- Se conservan los nombres de operación registrados por Microsoft 365, sin traducirlos ni inferir una acción distinta.
- Se reconocen cabeceras habituales en inglés, portugués y español, incluidos los ejemplos de SignIns suministrados. Para SignIns sin campo de operación se indica el tipo de inicio de sesión cuando el nombre del archivo permite identificarlo; en otro caso se indica que el tipo no está especificado.
- IP, usuario y acción no disponibles se marcan como **No consta en el registro**, sin inventar datos. La interfaz muestra cuántos eventos carecen de cada dato.
- AuthDetails puede contener únicamente ID de solicitud y detalles de autenticación: no se puede identificar usuario o IP si no figuran en el archivo. Esta versión no correlaciona automáticamente esos ID con otro archivo de SignIns.
- Se preserva el valor de IP registrado, incluidos sus posibles puertos o formato IPv6.
- Las fechas se normalizan a UTC. Fechas sin zona horaria se interpretan como UTC; fechas locales con barras, como día/mes/año. Las fechas vacías o no reconocidas conservan su texto y quedan al final.
- Se reconocen fechas numéricas de Excel con los sistemas 1900 y 1904. Se aceptan XLSX con cadenas compartidas o en línea. Se procesan las hojas `Registros…` cuando existen, evitando contar también los resúmenes. Si no existen se priorizan las hojas `Actividad…`; como alternativa se leen hojas con cabeceras reconocibles, excluyendo `Resumen…` y `Reputación IP…`.
- No se ejecutan fórmulas ni macros. Se pueden leer resultados de fórmulas guardados en el XLSX. No se admiten XLS antiguos, XLSX cifrados ni ZIP de CSV como entrada directa.

Los CSV se leen completos. Los XLSX se descomprimen y analizan por fragmentos, conservando los campos de actividad necesarios, para no cargar millones de celdas en memoria. El catálogo de cadenas compartidas, cuando existe, sí requiere memoria. Los eventos del informe y sus resúmenes se conservan en memoria para ordenar; con archivos grandes puede tardar. Los libros con más registros que el límite por hoja de Excel usan varias hojas dentro del mismo fichero.

## Desarrollo y validación

```sh
npm ci
npm test
npm run package
```

`src/activity.js` extrae y resume los eventos; `src/activity-reader.js` lee XLSX de forma incremental; `src/activity-app.js` controla la interfaz. Comparten con el conversor el lector CSV y el escritor XLSX, sin añadir la tabla de actividad a las descargas del conversor.

Se validó en Chromium la carga y descarga a partir del CSV UAL original completo y de su XLSX: ambos generan la misma actividad para los 50.000 eventos, con las fechas ordenadas y el resumen sumando 50.000. No se observaron errores JavaScript ni peticiones externas. La integración de AbuseIPDB se valida con respuestas simuladas, sin clave real ni consultas al proveedor: IP únicas, exclusión de rangos no públicos, comunicación entre HTML y script local, clave inválida, cuota, cancelación y generación de la tercera hoja. No se ha verificado una consulta real autenticada a AbuseIPDB en este entorno. Las pruebas automáticas cubren selección de campos, datos ausentes, SignIns, orden temporal, ambas codificaciones de texto XLSX, fechas numéricas, varias hojas y estructura del informe. Ningún log, identidad de usuario ni informe con datos reales se distribuye en los ZIP ni en el repositorio.
